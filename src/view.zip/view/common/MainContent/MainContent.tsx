import './MainContent.css';
export function MainContent() {
    return (
        <div className="main-content">
            This is Main Content
        </div>
    );
}