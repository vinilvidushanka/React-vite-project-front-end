import './Navbar.css';
export function Navbar() {
    return (
        <div className="navbar">
            This is navbar
        </div>
    );
}